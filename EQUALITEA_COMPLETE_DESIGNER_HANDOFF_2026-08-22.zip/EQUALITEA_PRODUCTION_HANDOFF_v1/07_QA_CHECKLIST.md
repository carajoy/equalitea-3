# 07 — QA Checklist

## Content
- [ ] Event name is correct.
- [ ] August 26, 2026 is correct.
- [ ] The Ben, West Palm Beach is correct.
- [ ] Theme line is correct.
- [ ] Program order matches the approved Chamber program.
- [ ] Adrienne Perceval = Closing Reflection.
- [ ] Charlee Nolan = Annual Hat Contest.
- [ ] Women’s Foundation spelling is used.
- [ ] All 11 participants are represented.
- [ ] Only four full biographies appear.
- [ ] Erica Grant uses supplied 2026 headshot and supplied bio.
- [ ] Erica Grant pronouns are preserved from supplied bio.
- [ ] The She’s Online Group appears as Program Design credit, not sponsor.

## Navigation
- [ ] Program anchor works.
- [ ] Speakers anchor works.
- [ ] Sponsors anchor works.
- [ ] About EqualiTEA anchor works.
- [ ] View Full Biographies jumps to biography section.
- [ ] No dead buttons.
- [ ] No invented external links.

## Sponsors
- [ ] Sponsor names match approved program.
- [ ] Sponsor levels match approved program.
- [ ] Canva classification does not override approved program.
- [ ] Every clickable sponsor logo uses a verified official destination.
- [ ] Unverified sponsor links remain non-clickable.
- [ ] Media Partner and Historic Exhibit Partner are included.
- [ ] Vendors are included as approved.

## Visual
- [ ] Desktop visually follows approved layout.
- [ ] Mobile visually follows approved layout.
- [ ] Panel has stronger visual emphasis.
- [ ] Speaker images are correctly matched.
- [ ] Gabrielle placeholder is unmistakably temporary.
- [ ] Adrienne placeholder is unmistakably temporary.
- [ ] The She’s Online Group logo is exact, not recreated.
- [ ] Suffrage colors retain intended meaning.
- [ ] 2027 Save the Date has a purposeful closing treatment.

## Mobile
- [ ] No horizontal overflow.
- [ ] No pinch-to-zoom needed.
- [ ] Type is readable at normal scale.
- [ ] Tap targets are comfortable.
- [ ] Sponsor logos remain legible.
- [ ] Headshots crop well on narrow screens.
- [ ] Page feels fast on cellular connection.

## Accessibility
- [ ] Heading hierarchy is semantic.
- [ ] Alt text is accurate.
- [ ] Keyboard navigation works.
- [ ] Focus is visible.
- [ ] Contrast passes.
- [ ] Reduced-motion preference is respected if motion exists.

## Final
- [ ] Compare rendered page side-by-side with `EQUALITEA_PROGRAM_LAYOUT.png`.
- [ ] Verify all names, titles, organizations, roles and order.
- [ ] Test every external URL.
- [ ] Test the QR destination.
- [ ] Obtain approval before deployment.
