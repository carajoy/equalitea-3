# Package Notes

Created: 2026-08-22

This v1 handoff intentionally separates:
- locked factual/program decisions,
- source documents,
- physically available assets,
- externally sourced/Canva assets still to retrieve,
- and publication QA.

The package does not include the Liquor Warehouse Community Toast campaign because that is a separate workstream and is explicitly outside the digital-program recommendation.
