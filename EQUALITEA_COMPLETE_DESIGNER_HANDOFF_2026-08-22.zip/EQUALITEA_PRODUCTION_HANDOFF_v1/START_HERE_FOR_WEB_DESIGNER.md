# Start Here for the Web Designer

## Status

The EqualiTEA digital program is already designed and built. Do not recreate it from the handoff documents.

Open `index.html` to view the finished program. The site is a static HTML and CSS package and does not require a build command or software dependency.

## Files to publish

Keep these items together with their existing names and folder structure:

* `index.html`
* `styles.css`
* `assets/`

Upload those items to the intended website directory. `index.html` is the entry page.

## Supporting materials included

The numbered Markdown files, `source-documents/`, reference assets, and `PRODUCTION_RUN_SUMMARY.md` are included for context and future revisions. They are supporting source materials, not a request to rebuild the program.

## Current owner revisions already completed

* Angela Manfredi’s credentials appear in program item 2.
* The page includes exactly four Featured Biographies.
* The complete official Florida Weekly logo is installed.
* Program Design uses only The She’s Online Group logo.
* LinkedIn points to `https://www.linkedin.com/company/wccpbc`.
* Facebook and Instagram use `@wccpbc`.
* Adrienne Percival is spelled with an `i`.

## Validation

The completed page passed desktop and phone browser checks with no horizontal overflow, no missing local references, no broken images, no duplicate HTML identifiers, and no browser console warnings or errors.

Nothing has been deployed from this package.
