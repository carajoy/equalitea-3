# 06 — Build Requirements

## Deliverable
Build a production-ready, mobile-first responsive webpage implementation intended to replace the event-day content on the existing 3rd Annual EqualiTEA page.

Current live destination:
https://womenschamber.biz/3rd-annual-tea/

## Implementation strategy
Because the final site integration method is controlled by the Chamber’s website provider, produce a framework-neutral package first:

- `index.html`
- `styles.css`
- `script.js` only if needed
- `/assets/` with optimized production images
- no unnecessary JavaScript
- no external framework dependency unless a concrete implementation requirement demands it

The code should be portable into a CMS/custom HTML environment.

## Performance
- Optimize all raster assets.
- Use responsive image sizing.
- Lazy-load below-the-fold images where appropriate.
- Avoid shipping giant original images when smaller web variants will do.
- Do not use a PDF embed as the program.
- Keep interaction code minimal.

## Accessibility
- Semantic headings.
- Descriptive alt text for every meaningful image.
- Decorative imagery gets empty alt text.
- Keyboard-accessible navigation.
- Visible focus states.
- Sufficient color contrast.
- Links must be distinguishable.
- Avoid text baked into raster images when it should be live HTML.

## Anchor IDs
Recommended:
- `#program`
- `#speakers`
- `#biographies`
- `#about-equalitea`
- `#sponsors`
- `#credits`
- `#save-the-date`

## Speaker cards
Today’s Voices:
- photo
- name
- professional title
- organization

Do not place full biography copy in the quick-view cards.

## Placeholder behavior
Gabrielle Benson and Adrienne Perceval currently use obvious placeholder assets.
They must remain visibly temporary and must never be mistaken for real headshots.

## Sponsor links
Open external sponsor destinations normally. Do not invent URLs. Keep unresolved links non-clickable until verified.

## QR
The supplied EqualiTEA QR asset is a project reference. Test its destination before deployment. Do not assume a QR destination is correct merely because the file exists.

## Publication
Do not publish automatically.
First produce a local/staging preview, test it, and obtain approval.
