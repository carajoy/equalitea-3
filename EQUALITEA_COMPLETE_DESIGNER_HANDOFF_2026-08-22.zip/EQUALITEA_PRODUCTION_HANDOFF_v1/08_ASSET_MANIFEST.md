# 08 — Asset Manifest

## Included and ready

### Branding / credit
- `assets/branding/2026_LOGO_THE_SHES_ONLINE_GROUP.png`
  - Exact user-supplied 2026 The She’s Online Group logo.
  - Use only for Program Design credit.

### Reference layout
- `assets/reference-layout/EQUALITEA_PROGRAM_LAYOUT.png`
  - Approved visual / information architecture reference.
  - Do not trust filler faces or any text that conflicts with locked content.

### Speaker headshots physically included
- `assets/headshots/Wendy_Sartory_Link_Headshot_2026.jpg`
- `assets/headshots/Dr_Cassondra_Corbin-Thaddies.png`
- `assets/headshots/Erica_Grant_2026.png`

### Intentional temporary placeholders
- `assets/headshots/PLACEHOLDER_Gabrielle_Benson_PA-C.png`
- `assets/headshots/PLACEHOLDER_Adrienne_Perceval.png`

### QR
- `assets/qr/EqualiTEA_QR_Code.jpg`
  - Test destination before production use.

## Speaker headshots to source from verified official pages

These were verified at the identity/source level but are not physically embedded in this handoff ZIP.

### Ashley Cacicedo Surdovel
Official Chamber board page:
https://womenschamber.biz/chamber/board-of-directors/

### Reisha Roopchand Allen
Official Chamber board page:
https://womenschamber.biz/chamber/board-of-directors/

### Julia Murphy
Official Habitat staff page:
https://habitatgreaterpbc.org/staff/

### Takeata King Pang
Use the Women’s Foundation official leadership page previously verified for the project. Confirm current page before downloading.

### Angela Manfredi
Official site:
https://angelamanfredi.com/

Canva source also contains Angela/panel assets:
- Design: `DAHQAICaBZM`
- Title: `EqualiTEA Emcee and Co-chairs-`
- View: https://www.canva.com/d/L8jsIbkYveDj8z-

### Charlee Nolan
Use Norton Museum of Art official source:
https://www.norton.org/

## Canva sponsor asset source
- Design ID: `DAHLlZuYuEc`
- Title: `3rd Annual EqualiTEA Sponsors and Guests`
- View: https://www.canva.com/d/nzmGr0UijKASdP0
- Edit: https://www.canva.com/d/-aHXiOdKLJDkZSs

The Canva design contains 23 pages with the sponsor board and individual sponsor/partner graphics. Retrieve exact logos from the design, but reconcile sponsor classification with `04_SPONSORS_AND_LINKS.md`.

## Source documents included
- `source-documents/3rd_Annual_EqualiTea_Program.docx`
- `source-documents/3rd_Annual_EqualiTea_Program.htm`
- `source-documents/BIOS.htm`
- `source-documents/Erica_Grant_Bio.docx`
- `source-documents/EqualiTEA_Digital_Program_Direction_Concise.htm`

## Asset safety rule
Never identify a speaker from appearance alone. Only use a photograph when the source context explicitly identifies that person.
